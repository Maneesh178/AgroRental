# Shopping Cart Feature - AgriRent

## Overview
A complete shopping cart system has been added to the AgriRent application, allowing users to add agricultural equipment and bazaar products to their cart before checkout.

## Backend Implementation

### Cart Schema (MongoDB)
Located in `server.js`, the Cart model includes:
- `userId` - Reference to user
- `items` - Array of cart items with:
  - `itemId` - Product/Equipment ID
  - `itemType` - 'equipment' or 'product'
  - `name`, `price`, `quantity`
  - `category`, `image`, `owner`
  - `addedAt` - Timestamp
- `totalPrice` - Calculated total
- `createdAt`, `updatedAt` - Timestamps

### API Endpoints

#### 1. **GET /api/cart**
- Retrieves user's cart
- Requires authentication
- Returns cart object with items and total

#### 2. **POST /api/cart/add**
- Adds item to cart
- Parameters:
  - `itemId` - Equipment or Product ID
  - `itemType` - 'equipment' or 'product'
  - `quantity` - Number of items
- Validates stock availability for products
- Combines duplicate items by increasing quantity

#### 3. **PUT /api/cart/:itemId**
- Updates cart item quantity
- Parameters:
  - `quantity` - New quantity
- If quantity is 0, removes item

#### 4. **DELETE /api/cart/:itemId**
- Removes specific item from cart
- Recalculates total

#### 5. **DELETE /api/cart**
- Clears entire cart
- Sets items to empty array

#### 6. **POST /api/cart/checkout**
- Processes checkout
- Creates bookings for equipment
- Updates product quantities
- Clears cart after successful checkout

## Frontend Implementation

### UI Components

#### Cart Button (Navigation)
- Located in navbar with cart icon
- Shows item count badge
- Clicking opens cart modal

#### Cart Modal
- Slide-in modal from right side
- Full height modal with:
  - Header with title and close button
  - Items list with scrolling
  - Footer with total and checkout button
  - "Continue Shopping" button

#### Cart Item Display
- Item image/icon
- Item name, category, price
- Quantity controls (+/- buttons and input)
- Remove button
- Subtotal calculation

#### Empty Cart State
- Shows empty cart icon
- Message when no items
- Checkout button disabled

### JavaScript Functions

#### Core Functions

```javascript
// Open/close cart modal
openCart()
closeCart()

// Add item to cart
addToCart(itemId, itemType, quantity)

// Manage cart items
updateCartItemQuantity(itemId, newQuantity)
removeFromCart(itemId)

// Display
loadCartUI()
updateCartCount()

// Checkout
handleCheckout()
```

#### User Interaction Flow
1. User views equipment/product by clicking card
2. Detail modal opens with "Add to Cart" button
3. User adds item to cart
4. Cart count updates in navbar
5. User can click cart icon to view cart
6. User can modify quantities or remove items
7. User clicks "Proceed to Checkout"
8. Cart is processed and cleared

### Styling
- Modern slide-in modal design
- Responsive layout (works on mobile/tablet/desktop)
- Color-coded buttons (green for primary, gray for secondary, red for remove)
- Animated transitions
- Clean typography and spacing

## Features

✅ **Add to Cart** - Equipment and products can be added
✅ **View Cart** - Modal shows all items with details
✅ **Quantity Management** - Increase/decrease quantities
✅ **Remove Items** - Remove individual items
✅ **Cart Count Badge** - Shows total items in cart
✅ **Cart Total** - Auto-calculated total price
✅ **Stock Validation** - Checks product availability
✅ **Checkout** - Process order and clear cart
✅ **Authentication** - Cart persists per user
✅ **Responsive Design** - Works on all screen sizes

## Usage

### For Users

1. **Adding Items:**
   - Browse equipment or products
   - Click on item to see details
   - Click "Add to Cart"
   - Item added with notification

2. **Viewing Cart:**
   - Click cart icon in navbar
   - See all items, quantities, and total
   - Modify quantities or remove items

3. **Checkout:**
   - Click "Proceed to Checkout"
   - Bookings created for equipment
   - Cart clears automatically
   - Confirmation shown

### For Developers

**Frontend Flow:**
```
index.html - Cart UI + JavaScript functions
- openCart() → loadCartUI() → displays items
- addToCart() → API call → updates count
- handleCheckout() → API call → clears cart
```

**Backend Flow:**
```
server.js - Cart routes
- GET /api/cart → returns cart
- POST /api/cart/add → validates & adds item
- PUT /api/cart/:id → updates quantity
- DELETE /api/cart/:id → removes item
- POST /api/cart/checkout → processes order
```

## API Response Examples

### Get Cart
```json
{
  "userId": "user_id",
  "items": [
    {
      "itemId": "eq_id",
      "itemType": "equipment",
      "name": "Tractor",
      "price": 2000,
      "quantity": 1,
      "category": "Heavy Machinery"
    }
  ],
  "totalPrice": 2000
}
```

### Add to Cart
```json
{
  "message": "Item added to cart",
  "cart": { ... }
}
```

## Testing

To test the cart feature:

1. Start the server: `npm start`
2. Navigate to the application
3. Login with a test account
4. Browse Equipment or Agri Bazaar
5. Click on an item and add to cart
6. Check cart icon updates
7. Click cart icon to view items
8. Test quantity updates
9. Test remove functionality
10. Test checkout process

## Notes

- Cart is stored per user in MongoDB
- Requires authentication for cart operations
- Stock is validated for products before adding
- Equipment status is updated on checkout
- Cart persists across sessions
- Mobile-responsive design included

---

**Version:** 1.0
**Status:** Complete and Ready for Use
