// Database Seed Script - scripts/seed.js
// Run with: node scripts/seed.js

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb+srv://Admin:Admin@cluster0.phbtcqz.mongodb.net/agrirent';

// Connect to MongoDB
mongoose.connect(MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Schemas (simplified for seeding)
const userSchema = new mongoose.Schema({
  name: String,
  fullName: String,
  email: { type: String, unique: true },
  password: String,
  phone: String,
  location: String,
  role: String,
  languages: [String],
  verified: Boolean,
  createdAt: Date
});

const toolSchema = new mongoose.Schema({
  name: String,
  description: String,
  category: String,
  type: String,
  rentPerDay: Number,
  price: Number,
  owner: String,
  ownerId: mongoose.Schema.Types.ObjectId,
  available: Boolean,
  status: String,
  location: String,
  image: String,
  specifications: Object,
  createdAt: Date
});

const smallProductSchema = new mongoose.Schema({
  name: String,
  category: String,
  description: String,
  price: Number,
  type: String,
  owner: String,
  ownerId: mongoose.Schema.Types.ObjectId,
  location: String,
  inStock: Boolean,
  quantity: Number,
  createdAt: Date
});

const User = mongoose.model('User', userSchema);
const Tool = mongoose.model('Tool', toolSchema);
const SmallProduct = mongoose.model('SmallProduct', smallProductSchema);

// Seed Data
async function seedDatabase() {
  try {
    console.log('🌱 Starting database seeding...');

    // Clear existing data
    await User.deleteMany({});
    await Tool.deleteMany({});
    await SmallProduct.deleteMany({});
    console.log('🗑️  Cleared existing data');

    // Create Users
    const hashedPassword = await bcrypt.hash('password123', 10);
    
    const users = await User.insertMany([
      {
        name: 'Admin User',
        fullName: 'Admin User',
        email: 'admin@agrirent.com',
        password: hashedPassword,
        phone: '+919876543210',
        location: 'Hubli, Karnataka',
        role: 'admin',
        languages: ['English', 'Kannada'],
        verified: true,
        createdAt: new Date()
      },
      {
        name: 'Ramesh Kumar',
        fullName: 'Ramesh Kumar',
        email: 'ramesh@example.com',
        password: hashedPassword,
        phone: '+919876543211',
        location: 'Hubli, Karnataka',
        role: 'owner',
        languages: ['English', 'Kannada', 'Hindi'],
        verified: true,
        createdAt: new Date()
      },
      {
        name: 'Suresh Patil',
        fullName: 'Suresh Patil',
        email: 'suresh@example.com',
        password: hashedPassword,
        phone: '+919876543212',
        location: 'Dharwad, Karnataka',
        role: 'owner',
        languages: ['Kannada', 'English'],
        verified: true,
        createdAt: new Date()
      },
      {
        name: 'Manjunath Gowda',
        fullName: 'Manjunath Gowda',
        email: 'manjunath@example.com',
        password: hashedPassword,
        phone: '+919876543213',
        location: 'Belgaum, Karnataka',
        role: 'owner',
        languages: ['Kannada'],
        verified: true,
        createdAt: new Date()
      },
      {
        name: 'Farmer John',
        fullName: 'John Doe',
        email: 'farmer@example.com',
        password: hashedPassword,
        phone: '+919876543214',
        location: 'Hubli, Karnataka',
        role: 'farmer',
        languages: ['English', 'Kannada'],
        verified: true,
        createdAt: new Date()
      }
    ]);

    console.log(`✅ Created ${users.length} users`);

    // Create Equipment/Tools
    const tools = await Tool.insertMany([
      {
        name: 'John Deere 5075E Tractor',
        description: '75HP tractor in excellent condition. Perfect for plowing, tilling, and general farm work.',
        category: 'Tractor',
        type: 'rent',
        rentPerDay: 2500,
        owner: 'Ramesh Kumar',
        ownerId: users[1]._id,
        available: true,
        status: 'available',
        location: 'Hubli, Karnataka',
        image: 'https://www.deere.com.mx/assets/images/region-3/products/tractors/large/8r-series/8295r/trator_8295r_campo1_large_6ad8df214da04053ad0e1c8b8c52318c15ce8a8d.jpg',
        specifications: {
          power: '75HP',
          year: '2020',
          condition: 'Excellent',
          fuelType: 'Diesel'
        },
        createdAt: new Date()
      },
      {
        name: 'Precision Seed Drill',
        description: 'High precision 12-row seed drill for optimal planting. Suitable for wheat, corn, and soybean.',
        category: 'Seeder',
        type: 'rent',
        rentPerDay: 1200,
        owner: 'Suresh Patil',
        ownerId: users[2]._id,
        available: true,
        status: 'available',
        location: 'Dharwad, Karnataka',
        specifications: {
          rows: '12',
          year: '2021',
          condition: 'Good'
        },
        createdAt: new Date()
      },
      {
        name: 'Combine Harvester',
        description: 'Large capacity combine harvester for wheat, rice, and other crops. High efficiency.',
        category: 'Harvester',
        type: 'rent',
        rentPerDay: 5000,
        owner: 'Manjunath Gowda',
        ownerId: users[3]._id,
        available: false,
        status: 'rented',
        location: 'Belgaum, Karnataka',
        specifications: {
          capacity: 'High',
          year: '2019',
          condition: 'Very Good',
          cuttingWidth: '5m'
        },
        createdAt: new Date()
      },
      {
        name: 'Massey Ferguson 245 DI',
        description: 'Reliable 50HP tractor. Great for small to medium farms. Well maintained.',
        category: 'Tractor',
        type: 'rent',
        rentPerDay: 2200,
        owner: 'Ramesh Kumar',
        ownerId: users[1]._id,
        available: true,
        status: 'available',
        location: 'Hubli, Karnataka',
        specifications: {
          power: '50HP',
          year: '2018',
          condition: 'Good'
        },
        createdAt: new Date()
      },
      {
        name: 'Rotary Tiller',
        description: 'Heavy-duty rotary tiller for soil preparation. Adjustable depth control.',
        category: 'Tiller',
        type: 'rent',
        rentPerDay: 800,
        owner: 'Suresh Patil',
        ownerId: users[2]._id,
        available: true,
        status: 'available',
        location: 'Dharwad, Karnataka',
        specifications: {
          width: '6 feet',
          year: '2021',
          condition: 'Excellent'
        },
        createdAt: new Date()
      },
      {
        name: 'Power Sprayer',
        description: 'High-pressure sprayer system for pesticides and fertilizers. Large tank capacity.',
        category: 'Sprayer',
        type: 'rent',
        rentPerDay: 600,
        owner: 'Ramesh Kumar',
        ownerId: users[1]._id,
        available: true,
        status: 'available',
        location: 'Hubli, Karnataka',
        specifications: {
          capacity: '200L',
          year: '2022',
          condition: 'Excellent',
          pressure: 'High'
        },
        createdAt: new Date()
      },
      {
        name: 'Cultivator',
        description: 'Multi-purpose cultivator for weeding and soil aeration. Adjustable tines.',
        category: 'Cultivator',
        type: 'rent',
        rentPerDay: 700,
        owner: 'Suresh Patil',
        ownerId: users[2]._id,
        available: true,
        status: 'available',
        location: 'Dharwad, Karnataka',
        specifications: {
          tines: '9',
          year: '2020',
          condition: 'Good'
        },
        createdAt: new Date()
      },
      {
        name: 'Thresher Machine',
        description: 'Efficient thresher for wheat, rice, and other grains. Low maintenance.',
        category: 'Thresher',
        type: 'rent',
        rentPerDay: 1500,
        owner: 'Manjunath Gowda',
        ownerId: users[3]._id,
        available: true,
        status: 'available',
        location: 'Belgaum, Karnataka',
        specifications: {
          capacity: 'Medium',
          year: '2019',
          condition: 'Good'
        },
        createdAt: new Date()
      }
    ]);

    console.log(`✅ Created ${tools.length} equipment items`);

    // Create Small Bazaar Products
    const smallProducts = await SmallProduct.insertMany([
      {
        name: 'Organic Wheat Seeds',
        category: 'seed',
        description: 'High-yielding organic wheat seeds. Disease resistant variety.',
        price: 50,
        type: 'sale',
        owner: 'Ramesh Kumar',
        ownerId: users[1]._id,
        location: 'Hubli, Karnataka',
        inStock: true,
        quantity: 100,
        createdAt: new Date()
      },
      {
        name: 'NPK Fertilizer',
        category: 'fertilizer',
        description: 'Balanced NPK 10-10-10 fertilizer. 50kg bag.',
        price: 800,
        type: 'sale',
        owner: 'Suresh Patil',
        ownerId: users[2]._id,
        location: 'Dharwad, Karnataka',
        inStock: true,
        quantity: 50,
        createdAt: new Date()
      },
      {
        name: 'Organic Pesticide',
        category: 'pesticide',
        description: 'Neem-based organic pesticide. Safe for environment.',
        price: 300,
        type: 'sale',
        owner: 'Manjunath Gowda',
        ownerId: users[3]._id,
        location: 'Belgaum, Karnataka',
        inStock: true,
        quantity: 30,
        createdAt: new Date()
      },
      {
        name: 'Hand Weeder',
        category: 'small_tool',
        description: 'Ergonomic hand weeder for garden and small farms.',
        price: 150,
        type: 'sale',
        owner: 'Ramesh Kumar',
        ownerId: users[1]._id,
        location: 'Hubli, Karnataka',
        inStock: true,
        quantity: 20,
        createdAt: new Date()
      },
      {
        name: 'Garden Hoe',
        category: 'small_tool',
        description: 'Sturdy garden hoe for soil preparation.',
        price: 200,
        type: 'sale',
        owner: 'Suresh Patil',
        ownerId: users[2]._id,
        location: 'Dharwad, Karnataka',
        inStock: true,
        quantity: 15,
        createdAt: new Date()
      },
      {
        name: 'Tomato Seeds (Hybrid)',
        category: 'seed',
        description: 'High-yield hybrid tomato seeds. 100g pack.',
        price: 120,
        type: 'sale',
        owner: 'Manjunath Gowda',
        ownerId: users[3]._id,
        location: 'Belgaum, Karnataka',
        inStock: true,
        quantity: 40,
        createdAt: new Date()
      },
      {
        name: 'Bio-Fertilizer',
        category: 'fertilizer',
        description: 'Organic bio-fertilizer enriched with beneficial microbes.',
        price: 400,
        type: 'sale',
        owner: 'Ramesh Kumar',
        ownerId: users[1]._id,
        location: 'Hubli, Karnataka',
        inStock: true,
        quantity: 25,
        createdAt: new Date()
      },
      {
        name: 'Fungicide Spray',
        category: 'pesticide',
        description: 'Effective fungicide for crop protection. 1L bottle.',
        price: 350,
        type: 'sale',
        owner: 'Suresh Patil',
        ownerId: users[2]._id,
        location: 'Dharwad, Karnataka',
        inStock: true,
        quantity: 20,
        createdAt: new Date()
      },
      {
        name: 'Pruning Shears',
        category: 'small_tool',
        description: 'Professional pruning shears with comfortable grip.',
        price: 250,
        type: 'sale',
        owner: 'Manjunath Gowda',
        ownerId: users[3]._id,
        location: 'Belgaum, Karnataka',
        inStock: true,
        quantity: 18,
        createdAt: new Date()
      },
      {
        name: 'Water Pump (Small)',
        category: 'small_tool',
        description: 'Portable water pump for irrigation. 1HP motor.',
        price: 3500,
        type: 'rent',
        owner: 'Ramesh Kumar',
        ownerId: users[1]._id,
        location: 'Hubli, Karnataka',
        inStock: true,
        quantity: 5,
        createdAt: new Date()
      }
    ]);

    console.log(`✅ Created ${smallProducts.length} small bazaar products`);

    console.log('\n🎉 Database seeded successfully!');
    console.log('\n📋 Login Credentials:');
    console.log('   Admin: admin@agrirent.com / password123');
    console.log('   Owner: ramesh@example.com / password123');
    console.log('   Farmer: farmer@example.com / password123');
    console.log('\n✅ All done! You can now start the server.');

    process.exit(0);
  } catch (error) {
    console.error('❌ Seeding error:', error);
    process.exit(1);
  }
}

// Run seeding
mongoose.connection.once('open', () => {
  console.log('✅ Connected to MongoDB');
  seedDatabase();
});

mongoose.connection.on('error', (err) => {
  console.error('❌ MongoDB connection error:', err);
  process.exit(1);
}); 