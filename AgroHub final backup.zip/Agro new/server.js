// AgriRent Backend Server - Complete with MongoDB, Chatbot, Small Bazaar
// File: server.js

const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const axios = require('axios');
const QRCode=require('qrcode');
const { Translate } = require('@google-cloud/translate').v2;
require('dotenv').config();

const app = express();

// Middleware
app.use(express.json());
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'secretkey';
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb+srv://Admin:Admin@cluster0.phbtcqz.mongodb.net/agrirent';

// === MongoDB Connection ===
mongoose.connect(MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

mongoose.connection.once('open', () => console.log('✅ MongoDB Connected!'));
mongoose.connection.on('error', (err) => console.error('❌ MongoDB Error:', err));

// === MongoDB Schemas ===

// User Schema
const userSchema = new mongoose.Schema({
  name: String,
  fullName: String,
  email: { type: String, unique: true, required: true },
  password: { type: String, required: true },
  phone: String,
  location: String,
  role: { type: String, enum: ['user', 'farmer', 'owner', 'admin'], default: 'user' },
  languages: [String],
  verified: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
});

// Equipment/Tool Schema
const toolSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: String,
  category: String,
  type: { type: String, enum: ['rent', 'sale', 'both'], default: 'rent' },
  rentPerDay: Number,
  price: Number,
  owner: String,
  ownerId: mongoose.Schema.Types.ObjectId,
  available: { type: Boolean, default: true },
  status: { type: String, enum: ['available', 'rented', 'sold'], default: 'available' },
  location: String,
  image: String,
  specifications: mongoose.Schema.Types.Mixed,
  createdAt: { type: Date, default: Date.now }
});

// Booking Schema
const bookingSchema = new mongoose.Schema({
  equipmentId: { type: mongoose.Schema.Types.ObjectId, ref: 'Tool', required: true },
  equipmentName: String,
  farmerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  farmerName: String,
  farmerEmail: String,
  ownerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  startDate: { type: Date, required: true },
  endDate: { type: Date, required: true },
  days: Number,
  pricePerDay: Number,
  totalPrice: Number,
  status: { type: String, enum: ['pending', 'confirmed', 'completed', 'cancelled'], default: 'pending' },
  notes: String,
  createdAt: { type: Date, default: Date.now },
  updatedAt: Date
});

// Complaint Schema
const complaintSchema = new mongoose.Schema({
  userEmail: String,
  userId: mongoose.Schema.Types.ObjectId,
  subject: String,
  message: String,
  status: { type: String, enum: ['Pending', 'In Progress', 'Resolved'], default: 'Pending' },
  createdAt: { type: Date, default: Date.now },
  resolvedAt: Date
});

// Small Bazaar Product Schema
const smallProductSchema = new mongoose.Schema({
  name: { type: String, required: true },
  category: { type: String, enum: ['pesticide', 'seed', 'small_tool', 'fertilizer'], default: 'small_tool' },
  description: String,
  price: Number,
  type: { type: String, enum: ['sale', 'rent'], default: 'sale' },
  owner: String,
  ownerId: mongoose.Schema.Types.ObjectId,
  location: String,
  image: String,
  inStock: { type: Boolean, default: true },
  quantity: Number,
  createdAt: { type: Date, default: Date.now }
});

// Chat Message Schema
const chatMessageSchema = new mongoose.Schema({
  sessionId: String,
  userId: mongoose.Schema.Types.ObjectId,
  message: String,
  response: String,
  timestamp: { type: Date, default: Date.now }
});

// Cart Schema
const cartSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  items: [{
    itemId: mongoose.Schema.Types.ObjectId,
    itemType: { type: String, enum: ['equipment', 'product'], required: true }, // equipment or product
    name: String,
    price: Number,
    quantity: { type: Number, default: 1 },
    category: String,
    image: String,
    owner: String,
    addedAt: { type: Date, default: Date.now }
  }],
  totalPrice: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// === Models ===
const User = mongoose.model('User', userSchema);
const Tool = mongoose.model('Tool', toolSchema);
const Booking = mongoose.model('Booking', bookingSchema);
const Complaint = mongoose.model('Complaint', complaintSchema);
const SmallProduct = mongoose.model('SmallProduct', smallProductSchema);
const ChatMessage = mongoose.model('ChatMessage', chatMessageSchema);
const Cart = mongoose.model('Cart', cartSchema);

// === JWT Helper ===
const generateToken = (user) => {
  return jwt.sign(
    { id: user._id, email: user.email, role: user.role },
    JWT_SECRET,
    { expiresIn: '30d' }
  );
};

// === Authentication Middleware ===
const authenticate = async (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ message: 'Authentication required' });
  }
  
  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(401).json({ message: 'Invalid token' });
  }
};

// === Admin Middleware ===
const requireAdmin = (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Admin access required' });
  }
  next();
};

// ==================== AUTH ROUTES ====================

// Register new user
app.post('/api/register', async (req, res) => {
  try {
    const { name, fullName, email, password, phone, location, role = 'user', languages } = req.body;
    
    // Validate required fields
    if (!email || !password) {
      return res.status(400).json({ message: 'Email and password are required' });
    }
    
    // Check if user exists
    const exists = await User.findOne({ email });
    if (exists) {
      return res.status(400).json({ message: 'User already exists' });
    }
    
    // Hash password
    const hashed = await bcrypt.hash(password, 10);
    
    // Create user
    const user = new User({
      name: name || fullName,
      fullName: fullName || name,
      email,
      password: hashed,
      phone,
      location,
      role,
      languages: languages || ['English']
    });
    
    await user.save();
    
    const token = generateToken(user);
    
    res.status(201).json({
      message: 'Registered successfully!',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        location: user.location
      }
    });
  } catch (err) {
    console.error('❌ Registration error:', err);
    res.status(500).json({ message: 'Error registering user' });
  }
});

// Login user
app.post('/api/login', async (req, res) => {
  try {
    const { email, password, role } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({ message: 'Email and password are required' });
    }
    
    // Find user
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    // Verify password
    const valid = await bcrypt.compare(password, user.password);
    if (!valid) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }
    
    // Check role if specified
    if (role && user.role !== role) {
      return res.status(403).json({ message: 'Invalid role for this user' });
    }
    
    // Generate token
    const token = generateToken(user);
    
    res.json({
      message: 'Login successful',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        location: user.location
      }
    });
  } catch (err) {
    console.error('❌ Login error:', err);
    res.status(500).json({ message: 'Login error' });
  }
});

// Get current user
app.get('/api/auth/me', authenticate, async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password');
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching user' });
  }
});

// ==================== TOOLS/EQUIPMENT ROUTES ====================

// Add new tool/equipment
app.post('/api/tools', authenticate, async (req, res) => {
  try {
    const { name, description, category, type, rentPerDay, price, location, specifications } = req.body;
    
    if (!name || !type) {
      return res.status(400).json({ message: 'Name and type are required' });
    }
    
    const user = await User.findById(req.user.id);
    
    const tool = new Tool({
      name,
      description,
      category,
      type,
      rentPerDay,
      price,
      owner: user.name,
      ownerId: user._id,
      location: location || user.location,
      specifications
    });
    
    await tool.save();
    
    res.status(201).json({ 
      message: 'Tool added successfully',
      tool 
    });
  } catch (err) {
    console.error('❌ Error adding tool:', err);
    res.status(500).json({ message: 'Error adding tool' });
  }
});

// Get all tools (with filters)
app.get('/api/tools', async (req, res) => {
  try {
    const { category, location, status, search, type, minPrice, maxPrice } = req.query;
    
    let query = {};
    
    if (category) query.category = category;
    if (location) query.location = new RegExp(location, 'i');
    if (status) query.status = status;
    if (type) query.type = type;
    
    if (search) {
      query.$or = [
        { name: new RegExp(search, 'i') },
        { description: new RegExp(search, 'i') },
        { location: new RegExp(search, 'i') }
      ];
    }
    
    if (minPrice || maxPrice) {
      query.rentPerDay = {};
      if (minPrice) query.rentPerDay.$gte = parseFloat(minPrice);
      if (maxPrice) query.rentPerDay.$lte = parseFloat(maxPrice);
    }
    
    const tools = await Tool.find(query).sort({ createdAt: -1 });
    
    res.json({
      total: tools.length,
      equipment: tools
    });
  } catch (err) {
    console.error('❌ Error fetching tools:', err);
    res.status(500).json({ message: 'Error fetching tools' });
  }
});

// Get single tool by ID
app.get('/api/tools/:id', async (req, res) => {
  try {
    const tool = await Tool.findById(req.params.id);
    if (!tool) {
      return res.status(404).json({ message: 'Tool not found' });
    }
    res.json(tool);
  } catch (err) {
    res.status(500).json({ message: 'Error fetching tool' });
  }
});

// Update tool
app.put('/api/tools/:id', authenticate, async (req, res) => {
  try {
    const tool = await Tool.findById(req.params.id);
    
    if (!tool) {
      return res.status(404).json({ message: 'Tool not found' });
    }
    
    if (tool.ownerId.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized' });
    }
    
    const updated = await Tool.findByIdAndUpdate(
      req.params.id,
      { $set: req.body },
      { new: true }
    );
    
    res.json({
      message: 'Tool updated successfully',
      tool: updated
    });
  } catch (err) {
    res.status(500).json({ message: 'Error updating tool' });
  }
});

// Delete tool
app.delete('/api/tools/:id', authenticate, async (req, res) => {
  try {
    const tool = await Tool.findById(req.params.id);
    
    if (!tool) {
      return res.status(404).json({ message: 'Tool not found' });
    }
    
    if (tool.ownerId.toString() !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized' });
    }
    
    await Tool.findByIdAndDelete(req.params.id);
    
    res.json({ message: 'Tool deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Error deleting tool' });
  }
});

// ==================== EQUIPMENT ALIAS ROUTES ====================
// Support both /api/tools and /api/equipment
app.get('/api/equipment', (req, res, next) => {
  req.url = '/api/tools';
  next();
});

app.get('/api/equipment/:id', (req, res, next) => {
  req.url = `/api/tools/${req.params.id}`;
  next();
});

app.post('/api/equipment', authenticate, (req, res, next) => {
  req.url = '/api/tools';
  next();
});

// ==================== BOOKING ROUTES ====================

// Create booking
app.post('/api/bookings', authenticate, async (req, res) => {
  try {
    const { equipmentId, startDate, endDate, notes } = req.body;
    
    if (!equipmentId || !startDate || !endDate) {
      return res.status(400).json({ message: 'Equipment ID, start date, and end date are required' });
    }
    
    const tool = await Tool.findById(equipmentId);
    if (!tool) {
      return res.status(404).json({ message: 'Equipment not found' });
    }
    
    if (tool.status !== 'available') {
      return res.status(400).json({ message: 'Equipment is not available' });
    }
    
    const user = await User.findById(req.user.id);
    
    // Calculate days and price
    const start = new Date(startDate);
    const end = new Date(endDate);
    const days = Math.ceil((end - start) / (1000 * 60 * 60 * 24));
    const totalPrice = tool.rentPerDay * days;
    
    const booking = new Booking({
      equipmentId: tool._id,
      equipmentName: tool.name,
      farmerId: user._id,
      farmerName: user.name,
      farmerEmail: user.email,
      ownerId: tool.ownerId,
      startDate,
      endDate,
      days,
      pricePerDay: tool.rentPerDay,
      totalPrice,
      notes
    });
    
    await booking.save();
    
    // Update tool status
    tool.status = 'rented';
    tool.available = false;
    await tool.save();
    
    res.status(201).json({
      message: 'Booking created successfully',
      booking
    });
  } catch (err) {
    console.error('❌ Booking error:', err);
    res.status(500).json({ message: 'Error creating booking' });
  }
});

// Get user bookings
app.get('/api/bookings', authenticate, async (req, res) => {
  try {
    let query = {};
    
    if (req.user.role === 'farmer' || req.user.role === 'user') {
      query.farmerId = req.user.id;
    } else if (req.user.role === 'owner') {
      query.ownerId = req.user.id;
    }
    // Admin sees all bookings
    
    const bookings = await Booking.find(query)
      .populate('equipmentId', 'name category')
      .sort({ createdAt: -1 });
    
    res.json({
      total: bookings.length,
      bookings
    });
  } catch (err) {
    res.status(500).json({ message: 'Error fetching bookings' });
  }
});

// Update booking status
app.put('/api/bookings/:id', authenticate, async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);
    
    if (!booking) {
      return res.status(404).json({ message: 'Booking not found' });
    }
    
    // Check authorization
    if (booking.farmerId.toString() !== req.user.id && 
        booking.ownerId.toString() !== req.user.id && 
        req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized' });
    }
    
    const { status } = req.body;
    
    if (status) {
      booking.status = status;
      booking.updatedAt = new Date();
      
      // If completed or cancelled, make equipment available again
      if (status === 'completed' || status === 'cancelled') {
        await Tool.findByIdAndUpdate(booking.equipmentId, {
          status: 'available',
          available: true
        });
      }
    }
    
    await booking.save();
    
    res.json({
      message: 'Booking updated successfully',
      booking
    });
  } catch (err) {
    res.status(500).json({ message: 'Error updating booking' });
  }
});

// ==================== CART ROUTES ====================

// Get user's cart
app.get('/api/cart', authenticate, async (req, res) => {
  try {
    let cart = await Cart.findOne({ userId: req.user.id });
    
    if (!cart) {
      cart = new Cart({ userId: req.user.id, items: [], totalPrice: 0 });
      await cart.save();
    }
    
    res.json(cart);
  } catch (err) {
    console.error('❌ Error fetching cart:', err);
    res.status(500).json({ message: 'Error fetching cart' });
  }
});

// Add item to cart
app.post('/api/cart/add', authenticate, async (req, res) => {
  try {
    const { itemId, itemType, quantity } = req.body;
    
    if (!itemId || !itemType || !quantity) {
      return res.status(400).json({ message: 'itemId, itemType, and quantity are required' });
    }
    
    // Fetch product/equipment details
    let item, itemPrice, itemName, itemImage, itemCategory, itemOwner;
    
    if (itemType === 'equipment') {
      item = await Tool.findById(itemId);
      if (!item) {
        return res.status(404).json({ message: 'Equipment not found' });
      }
      itemPrice = item.price || item.rentPerDay;
      itemName = item.name;
      itemImage = item.image;
      itemCategory = item.category;
      itemOwner = item.owner;
    } else if (itemType === 'product') {
      item = await SmallProduct.findById(itemId);
      if (!item) {
        return res.status(404).json({ message: 'Product not found' });
      }
      itemPrice = item.price;
      itemName = item.name;
      itemImage = item.image;
      itemCategory = item.category;
      itemOwner = item.owner;
      
      // Check if product is in stock
      if (!item.inStock || item.quantity < quantity) {
        return res.status(400).json({ message: 'Insufficient stock' });
      }
    } else {
      return res.status(400).json({ message: 'Invalid itemType. Use "equipment" or "product"' });
    }
    
    // Get or create cart
    let cart = await Cart.findOne({ userId: req.user.id });
    if (!cart) {
      cart = new Cart({ userId: req.user.id, items: [] });
    }
    
    // Check if item already exists in cart
    const existingItem = cart.items.find(i => i.itemId.toString() === itemId && i.itemType === itemType);
    
    if (existingItem) {
      existingItem.quantity += quantity;
    } else {
      cart.items.push({
        itemId,
        itemType,
        name: itemName,
        price: itemPrice,
        quantity,
        category: itemCategory,
        image: itemImage,
        owner: itemOwner
      });
    }
    
    // Calculate total
    cart.totalPrice = cart.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    cart.updatedAt = new Date();
    
    await cart.save();
    
    res.status(200).json({
      message: 'Item added to cart',
      cart
    });
  } catch (err) {
    console.error('❌ Error adding to cart:', err);
    res.status(500).json({ message: 'Error adding to cart' });
  }
});

// Update cart item quantity
app.put('/api/cart/:itemId', authenticate, async (req, res) => {
  try {
    const { quantity } = req.body;
    const { itemId } = req.params;
    
    if (quantity === undefined || quantity < 0) {
      return res.status(400).json({ message: 'Valid quantity is required' });
    }
    
    const cart = await Cart.findOne({ userId: req.user.id });
    if (!cart) {
      return res.status(404).json({ message: 'Cart not found' });
    }
    
    const cartItem = cart.items.find(i => i.itemId.toString() === itemId);
    if (!cartItem) {
      return res.status(404).json({ message: 'Item not found in cart' });
    }
    
    if (quantity === 0) {
      cart.items = cart.items.filter(i => i.itemId.toString() !== itemId);
    } else {
      cartItem.quantity = quantity;
    }
    
    // Recalculate total
    cart.totalPrice = cart.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    cart.updatedAt = new Date();
    
    await cart.save();
    
    res.json({
      message: 'Cart updated',
      cart
    });
  } catch (err) {
    console.error('❌ Error updating cart:', err);
    res.status(500).json({ message: 'Error updating cart' });
  }
});

// Remove item from cart
app.delete('/api/cart/:itemId', authenticate, async (req, res) => {
  try {
    const { itemId } = req.params;
    
    const cart = await Cart.findOne({ userId: req.user.id });
    if (!cart) {
      return res.status(404).json({ message: 'Cart not found' });
    }
    
    cart.items = cart.items.filter(i => i.itemId.toString() !== itemId);
    
    // Recalculate total
    cart.totalPrice = cart.items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    cart.updatedAt = new Date();
    
    await cart.save();
    
    res.json({
      message: 'Item removed from cart',
      cart
    });
  } catch (err) {
    console.error('❌ Error removing from cart:', err);
    res.status(500).json({ message: 'Error removing from cart' });
  }
});

// Clear cart
app.delete('/api/cart', authenticate, async (req, res) => {
  try {
    const cart = await Cart.findOne({ userId: req.user.id });
    if (!cart) {
      return res.status(404).json({ message: 'Cart not found' });
    }
    
    cart.items = [];
    cart.totalPrice = 0;
    cart.updatedAt = new Date();
    
    await cart.save();
    
    res.json({
      message: 'Cart cleared',
      cart
    });
  } catch (err) {
    console.error('❌ Error clearing cart:', err);
    res.status(500).json({ message: 'Error clearing cart' });
  }
});

// Checkout (initiate UPI payment) - NOTE: this endpoint no longer creates bookings or updates inventory.
// It returns a UPI payment URL that the frontend can use to redirect the user to their UPI app (e.g. PhonePe).
app.post('/api/cart/checkout', authenticate, async (req, res) => {
  try {
    const cart = await Cart.findOne({ userId: req.user.id });

    if (!cart || cart.items.length === 0) {
      return res.status(400).json({ message: 'Cart is empty' });
    }

    // Compute total amount (fallback to item sum if totalPrice missing)
    const amount = cart.totalPrice && cart.totalPrice > 0
      ? cart.totalPrice
      : cart.items.reduce((sum, it) => sum + ((it.price || 0) * (it.quantity || 1)), 0);

    // Configure UPI details via env variables (fallbacks provided)
    const upiVpa = process.env.PHONEPE_UPI || 'agri@upi';
    const payeeName = process.env.PHONEPE_NAME || 'AgriRent';
    const note = process.env.PAYMENT_NOTE || 'AgriRent payment';

    // Build a UPI deep link. Mobile UPI apps should handle this URI.
    const upiUrl = `upi://pay?pa=${encodeURIComponent(upiVpa)}&pn=${encodeURIComponent(payeeName)}&am=${encodeURIComponent((Number(amount) || 0).toFixed(2))}&cu=INR&tn=${encodeURIComponent(note)}`;
    const qr = await QRCode.toDataURL(upiUrl);
    // Respond with the payment URL; frontend should redirect the user to this link.
    res.json({
      message: 'Proceed to UPI payment',
      paymentUrl: upiUrl,
      qrCode: qr,
      amount
    });
  } catch (err) {
    console.error('❌ Error initiating checkout (UPI):', err);
    res.status(500).json({ message: 'Error initiating payment' });
  }
});

// ==================== SMALL BAZAAR ROUTES ====================

// Add small product
app.post('/api/small-products', authenticate, async (req, res) => {
  try {
    const { name, category, description, price, type, location, quantity } = req.body;
    
    if (!name || !price) {
      return res.status(400).json({ message: 'Name and price are required' });
    }
    
    const user = await User.findById(req.user.id);
    
    const product = new SmallProduct({
      name,
      category,
      description,
      price,
      type: type || 'sale',
      owner: user.name,
      ownerId: user._id,
      location: location || user.location,
      quantity
    });
    
    await product.save();
    
    res.status(201).json({
      message: 'Product added successfully to Small Bazaar',
      product
    });
  } catch (err) {
    console.error('❌ Error adding product:', err);
    res.status(500).json({ message: 'Error adding product' });
  }
});

// Get all small products
app.get('/api/small-products', async (req, res) => {
  try {
    const { category, type, location, search } = req.query;
    
    let query = {};
    
    if (category) query.category = category;
    if (type) query.type = type;
    if (location) query.location = new RegExp(location, 'i');
    
    if (search) {
      query.$or = [
        { name: new RegExp(search, 'i') },
        { description: new RegExp(search, 'i') }
      ];
    }
    
    const products = await SmallProduct.find(query).sort({ createdAt: -1 });
    
    res.json({
      total: products.length,
      products
    });
  } catch (err) {
    res.status(500).json({ message: 'Error fetching small products' });
  }
});

// ==================== COMPLAINTS ROUTES ====================

// Submit complaint
app.post('/api/complaints', authenticate, async (req, res) => {
  try {
    const { subject, message } = req.body;
    
    if (!subject || !message) {
      return res.status(400).json({ message: 'Subject and message are required' });
    }
    
    const user = await User.findById(req.user.id);
    
    const complaint = new Complaint({
      userEmail: user.email,
      userId: user._id,
      subject,
      message
    });
    
    await complaint.save();
    
    res.status(201).json({
      message: 'Complaint submitted successfully!',
      complaint
    });
  } catch (err) {
    console.error('❌ Error submitting complaint:', err);
    res.status(500).json({ message: 'Error submitting complaint' });
  }
});

// Get all complaints (admin only)
app.get('/api/admin/complaints', authenticate, requireAdmin, async (req, res) => {
  try {
    const complaints = await Complaint.find().sort({ createdAt: -1 });
    res.json({
      total: complaints.length,
      complaints
    });
  } catch (err) {
    res.status(500).json({ message: 'Error fetching complaints' });
  }
});

// Update complaint status (admin only)
app.put('/api/admin/complaints/:id', authenticate, requireAdmin, async (req, res) => {
  try {
    const { status } = req.body;
    
    const complaint = await Complaint.findByIdAndUpdate(
      req.params.id,
      { 
        status: status || 'Resolved',
        resolvedAt: status === 'Resolved' ? new Date() : null
      },
      { new: true }
    );
    
    if (!complaint) {
      return res.status(404).json({ message: 'Complaint not found' });
    }
    
    res.json({
      message: 'Complaint updated successfully',
      complaint
    });
  } catch (err) {
    res.status(500).json({ message: 'Error updating complaint' });
  }
});

// ==================== CHATBOT ROUTES ====================

// Replace the chatbot route in server.js with this:

// ==================== CHATBOT ROUTES ====================

// Ollama Chatbot (Local AI) - Fixed Version
app.post('/api/chatbot', async (req, res) => {
  const { userInput, sessionId } = req.body;
  
  if (!userInput) {
    return res.status(400).json({ message: 'User input is required' });
  }

  try {
    const context = `
You are AgroCopilot — an AI assistant for farmers using AgriRent platform.

🎯 VERY IMPORTANT — ALWAYS follow this format:
- Use clear markdown
- Use headings (##)
- Use bullet points (•)
- Use line breaks
- Avoid long paragraphs
- Make answers short and neat

Example format:
## Seeds
• Choose high-quality seeds  
• Save seeds for next season  

## Tools
• Rent tractors from our platform
• Buy small tools from bazaar

## Equipment Available
• Tractors - ₹2000-2500/day
• Harvesters - ₹5000/day
• Seeders - ₹1200/day

You can help with:
- Finding agricultural equipment
- Rental pricing information
- Location-based recommendations
- Farming tips and best practices
- Platform navigation

Now answer the user question below in the SAME FORMAT.

User: ${userInput}
`;

    let botReply;
    
    try {
      // Try Ollama first
      const response = await axios.post(
        'http://localhost:11434/api/generate',
        {
          model: 'phi3',
          prompt: context,
          stream: false
        },
        // { timeout: 15000 } // 15 second timeout
      );
      
      botReply = response.data.response;
      console.log('✅ Ollama AI response generated');
      
    } catch (ollamaError) {
      // Fallback to rule-based responses if Ollama fails
      console.log('⚠️ Ollama not available, using fallback responses');
      botReply = generateFallbackResponse(userInput);
    }

    // Save chat message to database (if user is authenticated)
    if (req.user) {
      try {
        const chatMsg = new ChatMessage({
          sessionId: sessionId || 'anonymous',
          userId: req.user.id,
          message: userInput,
          response: botReply
        });
        await chatMsg.save();
      } catch (dbError) {
        console.error('⚠️ Failed to save chat message:', dbError.message);
        // Don't fail the request if database save fails
      }
    }

    res.json({ botReply, response: botReply });
    
  } catch (err) {
    console.error('💥 Chatbot Error:', err.message);
    
    // Ultimate fallback
    const fallback = generateFallbackResponse(userInput);
    res.json({ botReply: fallback, response: fallback });
  }
});

// Fallback chatbot responses
function generateFallbackResponse(input) {
  const lowerInput = input.toLowerCase();
  
  if (lowerInput.includes('tractor')) {
    return `## 🚜 Tractors Available

• **John Deere 5075E** - ₹2500/day in Hubli
• **Massey Ferguson** - ₹2200/day in Bijapur

### How to Rent:
• Browse equipment catalog
• Select your preferred tractor
• Book for your required dates
• Equipment delivered to your location`;
  }
  
  if (lowerInput.includes('price') || lowerInput.includes('cost')) {
    return `## 💰 Equipment Pricing

• **Tractors**: ₹2000-2500/day
• **Harvesters**: ₹5000/day
• **Seeders**: ₹1200/day
• **Tillers**: ₹800/day
• **Sprayers**: ₹600/day

All prices include basic maintenance. Fuel extra.`;
  }
  
  if (lowerInput.includes('location') || lowerInput.includes('where')) {
    return `## 📍 Available Locations

• Hubli, Karnataka
• Dharwad, Karnataka
• Belgaum, Karnataka
• Bijapur, Karnataka

We're expanding to more locations soon!`;
  }
  
  if (lowerInput.includes('book') || lowerInput.includes('rent')) {
    return `## 📝 How to Book Equipment

• **Step 1**: Browse equipment catalog
• **Step 2**: Select equipment & dates
• **Step 3**: Complete booking form
• **Step 4**: Confirm payment
• **Step 5**: Equipment delivered!

Need help? Contact owner directly through platform.`;
  }
  
  if (lowerInput.includes('seed') || lowerInput.includes('fertilizer') || lowerInput.includes('pesticide')) {
    return `## 🌱 Small Bazaar

Visit our Small Bazaar for:
• **Seeds**: High-quality varieties
• **Fertilizers**: Organic & chemical
• **Pesticides**: Safe & effective
• **Small tools**: Hand tools & accessories

Check the Small Bazaar section in our app!`;
  }
  
  if (lowerInput.includes('crop') || lowerInput.includes('grow') || lowerInput.includes('farm')) {
    return `## 🌾 Farming Tips

• **Soil Testing**: Check soil health regularly
• **Crop Rotation**: Change crops each season
• **Water Management**: Use drip irrigation
• **Equipment**: Rent modern tools from our platform

Need specific farming advice? Ask me about crops, seasons, or equipment!`;
  }
  
  return `## 👋 Welcome to AgriRent!

I can help you with:
• **Finding equipment** (tractors, harvesters, etc.)
• **Rental pricing** and availability
• **Location-based** recommendations
• **Booking process** guidance
• **Farming tips** and best practices

What would you like to know?`;
}

// ==================== LOCATION ROUTES ====================

// Detect location (simplified)
app.get('/api/location/detect', (req, res) => {
  res.json({
    city: 'Hubli',
    state: 'Karnataka',
    country: 'India',
    coordinates: {
      lat: 15.3647,
      lng: 75.1240
    }
  });
});

// Get nearby equipment
app.get('/api/equipment/nearby', async (req, res) => {
  const { lat, lng, radius = 50, location } = req.query;
  
  try {
    let query = { status: 'available' };
    
    if (location) {
      query.location = new RegExp(location, 'i');
    }
    
    const equipment = await Tool.find(query).limit(20);
    
    res.json({
      total: equipment.length,
      equipment
    });
  } catch (err) {
    res.status(500).json({ message: 'Error fetching nearby equipment' });
  }
});

// ==================== MULTILINGUAL SUPPORT ====================

// Get language translations
app.get('/api/lang/:lang', (req, res) => {
  const lang = req.params.lang;
  const filePath = path.join(__dirname, 'public', 'lang', `${lang}.json`);
  
  if (fs.existsSync(filePath)) {
    const jsonData = fs.readFileSync(filePath, 'utf-8');
    res.json(JSON.parse(jsonData));
  } else {
    res.status(404).json({ message: 'Language not found' });
  }
});

// ==================== ADMIN ROUTES ====================

// Get admin dashboard stats
app.get('/api/admin/stats', authenticate, requireAdmin, async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();
    const totalEquipment = await Tool.countDocuments();
    const totalBookings = await Booking.countDocuments();
    const totalProducts = await SmallProduct.countDocuments();
    const pendingComplaints = await Complaint.countDocuments({ status: 'Pending' });
    const activeRentals = await Booking.countDocuments({ status: 'confirmed' });
    
    const revenueData = await Booking.aggregate([
      { $match: { status: { $in: ['confirmed', 'completed'] } } },
      { $group: { _id: null, total: { $sum: '$totalPrice' } } }
    ]);
    
    const revenue = revenueData.length > 0 ? revenueData[0].total : 0;
    
    res.json({
      totalUsers,
      totalEquipment,
      totalBookings,
      totalProducts,
      pendingComplaints,
      activeRentals,
      revenue
    });
  } catch (err) {
    res.status(500).json({ message: 'Error fetching stats' });
  }
});

// Get all users (admin only)
app.get('/api/admin/users', authenticate, requireAdmin, async (req, res) => {
  try {
    const users = await User.find().select('-password').sort({ createdAt: -1 });
    res.json({
      total: users.length,
      users
    });
  } catch (err) {
    res.status(500).json({ message: 'Error fetching users' });
  }
});

// Delete user (admin only)
app.delete('/api/admin/users/:id', authenticate, requireAdmin, async (req, res) => {
  try {
    await User.findByIdAndDelete(req.params.id);
    res.json({ message: 'User deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Error deleting user' });
  }
});

// ==================== SERVE STATIC FRONTEND ====================

// Default route → Home page
app.get('/', (req, res) => {
  const homeHtml = path.join(__dirname, 'public', 'index.html');
  const homePath = path.join(__dirname, 'public', 'home', 'index.html');
  
  if (fs.existsSync(homeHtml)) {
    res.sendFile(homeHtml);
  } else if (fs.existsSync(homePath)) {
    res.sendFile(homePath);
  } else {
    res.send(`
      <!DOCTYPE html>
      <html>
      <head>
        <title>AgriRent - Agricultural Equipment Rental</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            text-align: center;
          }
          h1 { color: #2ecc71; }
          .status { color: #27ae60; font-size: 1.2em; margin: 20px 0; }
          .endpoints { text-align: left; background: #f5f5f5; padding: 20px; border-radius: 8px; }
          .endpoint { margin: 10px 0; font-family: monospace; }
        </style>
      </head>
      <body>
        <h1>🚜 AgriRent Backend Server</h1>
        <div class="status">✅ Server is running successfully!</div>
        <div class="endpoints">
          <h2>Available API Endpoints:</h2>
          <div class="endpoint"><strong>POST</strong> /api/register - Register new user</div>
          <div class="endpoint"><strong>POST</strong> /api/login - User login</div>
          <div class="endpoint"><strong>GET</strong> /api/tools - Get all equipment</div>
          <div class="endpoint"><strong>POST</strong> /api/tools - Add equipment</div>
          <div class="endpoint"><strong>GET</strong> /api/small-products - Get bazaar products</div>
          <div class="endpoint"><strong>POST</strong> /api/bookings - Create booking</div>
          <div class="endpoint"><strong>POST</strong> /api/chatbot - Chat with AgriBot</div>
          <div class="endpoint"><strong>POST</strong> /api/complaints - Submit complaint</div>
          <div class="endpoint"><strong>GET</strong> /api/admin/stats - Admin dashboard</div>
        </div>
        <p style="margin-top: 30px; color: #666;">
          Place your frontend files in the <code>public/</code> directory
        </p>
      </body>
      </html>
    `);
  }
});

// Admin page route
app.get('/admin', (req, res) => {
  const adminPath = path.join(__dirname, 'public', 'admin', 'index.html');
  if (fs.existsSync(adminPath)) {
    res.sendFile(adminPath);
  } else {
    res.status(404).send('Admin page not found. Please create public/admin/index.html');
  }
});

// ==================== ERROR HANDLING ====================

// 404 handler
app.use((req, res) => {
  res.status(404).json({ 
    message: 'Route not found',
    path: req.path,
    method: req.method
  });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error('💥 Server error:', err);
  res.status(500).json({ 
    message: 'Internal server error',
    error: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// ==================== START SERVER ====================

app.listen(PORT, () => {
  console.log(`
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║   🚜 AgriRent Server Started Successfully!                ║
║                                                           ║
║   🌐 Server running at: http://localhost:${PORT}         ║
║   📡 API available at:  http://localhost:${PORT}/api     ║
║   🔧 Environment: ${process.env.NODE_ENV || 'development'}                      ║
║                                                           ║
║   Available Services:                                     ║
║   ✅ MongoDB Connected                                    ║
║   ✅ Authentication (JWT)                                 ║
║   ✅ Equipment Management                                 ║
║   ✅ Booking System                                       ║
║   ✅ Small Bazaar                                         ║
║   ✅ Complaints System                                    ║
║   ✅ AI Chatbot (Ollama/Fallback)                        ║
║   ✅ Multi-language Support                               ║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
  `);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('👋 SIGTERM received. Closing server gracefully...');
  mongoose.connection.close(() => {
    console.log('✅ MongoDB connection closed');
    process.exit(0);
  });
});

module.exports = app;